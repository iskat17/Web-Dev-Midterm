Scott Vincent Red
BSIT 2B

This is my midterm project in my subject Web Development 